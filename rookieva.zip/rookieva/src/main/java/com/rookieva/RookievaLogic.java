package com.rookieva;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.RaycastContext;

public class RookievaLogic {
    private static long lastNano = 0;
    private static float lastYaw, lastPitch;
    private static boolean hasLast = false;

    public static void frame() {
        MinecraftClient mc = MinecraftClient.getInstance();
        RookievaConfig c = RookievaConfig.I;

        long now = System.nanoTime();
        float dt = lastNano == 0 ? 0.016f : Math.min((now - lastNano) / 1e9f, 0.1f);
        lastNano = now;

        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.currentScreen != null || (!c.aimbot && !c.assist)) {
            hasLast = false;
            return;
        }

        float tickDelta = mc.getRenderTickCounter().getTickProgress(false);

        boolean userMoved = hasLast &&
                (Math.abs(MathHelper.wrapDegrees(p.getYaw() - lastYaw)) > 0.01f
                        || Math.abs(p.getPitch() - lastPitch) > 0.01f);

        boolean aimbotActive = c.aimbot && (!c.holdToAim || RookievaClient.aimKey.isPressed());
        boolean assistActive = !aimbotActive && c.assist && userMoved;

        if (!aimbotActive && !assistActive) {
            lastYaw = p.getYaw(); lastPitch = p.getPitch(); hasLast = true;
            return;
        }

        Vec3d eye = p.getCameraPosVec(tickDelta);
        float curYaw = p.getYaw(), curPitch = p.getPitch();

        float bestDist = Float.MAX_VALUE, bestYd = 0, bestPd = 0;
        boolean found = false;

        for (PlayerEntity e : mc.world.getPlayers()) {
            if (e == p || !e.isAlive() || e.isSpectator()) continue;

            Vec3d pos = e.getLerpedPos(tickDelta);
            Vec3d aim = new Vec3d(pos.x, pos.y + e.getHeight() * c.aimHeight, pos.z);
            if (eye.distanceTo(aim) > c.range) continue;

            double dx = aim.x - eye.x, dy = aim.y - eye.y, dz = aim.z - eye.z;
            float tYaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
            float tPitch = (float) -Math.toDegrees(Math.atan2(dy, Math.hypot(dx, dz)));

            float yd = MathHelper.wrapDegrees(tYaw - curYaw);
            float pd = tPitch - curPitch;
            float ang = (float) Math.hypot(yd, pd);

            if (ang > c.fov / 2.0) continue;
            if (c.visibleOnly && !canSee(mc, p, eye, aim)) continue;

            if (ang < bestDist) { bestDist = ang; bestYd = yd; bestPd = pd; found = true; }
        }

        if (found && bestDist > c.deadzone) {
            float speed = (float) (aimbotActive ? c.aimbotSpeed : c.assistStrength);
            float factor = 1f - (float) Math.exp(-speed * dt);

            float sy = bestYd * factor;
            float sp = bestPd * factor;

            float maxStep = (float) (c.maxTurnSpeed * dt);
            float len = (float) Math.hypot(sy, sp);
            if (len > maxStep && len > 0) { sy *= maxStep / len; sp *= maxStep / len; }

            // changeLookDirection, mouse hareketiyle aynı yolu kullanır (yaw/prevYaw'ı birlikte günceller)
            p.changeLookDirection(sy / 0.15, sp / 0.15);
        }

        lastYaw = p.getYaw(); lastPitch = p.getPitch(); hasLast = true;
    }

    private static boolean canSee(MinecraftClient mc, PlayerEntity self, Vec3d from, Vec3d to) {
        return mc.world.raycast(new RaycastContext(from, to,
                RaycastContext.ShapeType.COLLIDER, RaycastContext.FluidHandling.NONE, self))
                .getType() == HitResult.Type.MISS;
    }
}
