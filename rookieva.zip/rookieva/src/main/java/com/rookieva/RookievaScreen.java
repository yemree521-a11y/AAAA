package com.rookieva;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;

public class RookievaScreen extends Screen {
    private int index = 0;

    public RookievaScreen() { super(Text.literal("Rookieva")); }

    @Override
    protected void init() {
        index = 0;
        RookievaConfig c = RookievaConfig.I;

        toggle("Aimbot", () -> c.aimbot, v -> c.aimbot = v);
        toggle("Aim Assist", () -> c.assist, v -> c.assist = v);
        toggle("Tuşa Basılıyken", () -> c.holdToAim, v -> c.holdToAim = v);
        toggle("Duvar Arkası Engel", () -> c.visibleOnly, v -> c.visibleOnly = v);

        slider("Menzil", 1, 6, c.range, "%.1f blok", v -> c.range = v);
        slider("Görüş Açısı (FOV)", 5, 180, c.fov, "%.0f°", v -> c.fov = v);
        slider("Aimbot Hızı", 1, 20, c.aimbotSpeed, "%.1f", v -> c.aimbotSpeed = v);
        slider("Assist Gücü", 0.5, 15, c.assistStrength, "%.1f", v -> c.assistStrength = v);
        slider("Max Dönüş Hızı", 30, 720, c.maxTurnSpeed, "%.0f°/sn", v -> c.maxTurnSpeed = v);
        slider("Hedef Yüksekliği", 0, 1, c.aimHeight, "%.2f", v -> c.aimHeight = v);
        slider("Ölü Bölge", 0, 3, c.deadzone, "%.2f°", v -> c.deadzone = v);

        addDrawableChild(ButtonWidget.builder(Text.literal("Kaydet ve Kapat"), b -> close())
                .dimensions(width / 2 - 100, height - 30, 200, 20).build());
    }

    private int px() { return width / 2 - 155 + (index % 2) * 160; }
    private int py() { return 40 + (index / 2) * 24; }

    private void toggle(String name, BooleanSupplier get, Consumer<Boolean> set) {
        addDrawableChild(ButtonWidget.builder(label(name, get.getAsBoolean()), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(label(name, get.getAsBoolean()));
        }).dimensions(px(), py(), 150, 20).build());
        index++;
    }

    private Text label(String n, boolean on) {
        return Text.literal(n + ": " + (on ? "§aAÇIK" : "§cKAPALI"));
    }

    private void slider(String name, double min, double max, double val, String fmt, DoubleConsumer set) {
        addDrawableChild(new Slider(px(), py(), 150, 20, name, min, max, val, fmt, set));
        index++;
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("§lRookieva"), width / 2, 15, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Hızı düşük tut = daha doğal takip"), width / 2, 27, 0xFFAAAAAA);
    }

    @Override
    public void close() {
        RookievaConfig.save();
        super.close();
    }

    private static class Slider extends SliderWidget {
        private final String name, fmt;
        private final double min, max;
        private final DoubleConsumer setter;

        Slider(int x, int y, int w, int h, String name, double min, double max, double val, String fmt, DoubleConsumer setter) {
            super(x, y, w, h, Text.empty(), (val - min) / (max - min));
            this.name = name; this.min = min; this.max = max; this.fmt = fmt; this.setter = setter;
            updateMessage();
        }

        private double real() { return min + value * (max - min); }

        @Override protected void updateMessage() {
            setMessage(Text.literal(name + ": " + String.format(fmt, real())));
        }

        @Override protected void applyValue() { setter.accept(real()); }
    }
}
