package com.rookieva;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class RookievaClient implements ClientModInitializer {
    public static KeyBinding menuKey, aimKey;

    @Override
    public void onInitializeClient() {
        RookievaConfig.load();

        KeyBinding.Category category = KeyBinding.Category.create(Identifier.of("rookieva", "main"));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.rookieva.menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, category));
        aimKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.rookieva.aim", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_V, category));

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (menuKey.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new RookievaScreen());
            }
        });

        // Her render karesinde çalışır -> kafa titremesi olmaz
        HudRenderCallback.EVENT.register((ctx, tickCounter) -> RookievaLogic.frame());
    }
}
