package com.rookieva;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

public class RookievaConfig {
    public static RookievaConfig I = new RookievaConfig();

    public boolean aimbot = false;
    public boolean assist = false;
    public boolean holdToAim = true;
    public boolean visibleOnly = true;
    public double range = 4.5;
    public double fov = 60;
    public double aimbotSpeed = 6;
    public double assistStrength = 3;
    public double maxTurnSpeed = 220;
    public double aimHeight = 0.85;
    public double deadzone = 0.6;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static Path path() { return FabricLoader.getInstance().getConfigDir().resolve("rookieva.json"); }

    public static void load() {
        try {
            if (Files.exists(path())) {
                RookievaConfig c = GSON.fromJson(Files.readString(path()), RookievaConfig.class);
                if (c != null) I = c;
            }
        } catch (Exception ignored) { I = new RookievaConfig(); }
    }

    public static void save() {
        try { Files.writeString(path(), GSON.toJson(I)); } catch (Exception ignored) {}
    }
}
