ROOKIEVA  (Fabric, Minecraft 1.21.11)

JAR'I NASIL ALIRSIN
A) GitHub ile (kurulum yok):
   1) github.com'da yeni repo aç, bu klasörün içindekileri (.github dahil) yükle.
   2) Actions sekmesi > "build" çalışınca "rookieva-jar" artifact'ini indir.
   3) İçinden çıkan rookieva-1.0.0.jar dosyasını mods klasörüne at.
B) Kendi bilgisayarında:
   JDK 21 + Gradle 9.x kur, bu klasörde:  gradle build
   Jar: build/libs/rookieva-1.0.0.jar  (-sources olanı değil)

GEREKENLER (mods klasöründe): Fabric Loader 0.18.1+, Fabric API (1.21.11). Cloth Config gerekmez.

KULLANIM
  Sağ Shift = menü | V (basılı tut) = Aimbot | Aim Assist = mouse'u oynatırken hafif çeker
  Ayarlar: config/rookieva.json
